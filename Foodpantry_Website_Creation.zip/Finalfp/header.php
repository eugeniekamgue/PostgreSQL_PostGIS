<?php
    
  	 echo '<div id="headertext">
     <a href="index.php">Home</a> |
     <a href="about.html">About Us</a> |
     <a href="search.html">Search Food Pantry</a> |
     <a href="register.html">Register</a></li> |
     <a href="login.html">Login</a></li> |
     <a href="logout.php">Logout</a></li> |
     <a href="admin.html">Admin</a></li>
     </div>';
    
?>
