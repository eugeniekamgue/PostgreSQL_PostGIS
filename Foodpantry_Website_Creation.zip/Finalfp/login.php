<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Foodpantry Locations</title>
</head>
<body>
  <h2>Foodpantry Locations</h2>

<?php
  
  #Connect to the database

require('header.php');
session_start();
require('connectvars.php');

// If the form is submitted
if (isset($_POST['username']) and isset($_POST['password'])){
// Assigning posted values to variables.
  $username = $_POST['username'];
  $password = $_POST['password'];
  // Checking the values are existing in the database or not
  $query = "SELECT * FROM `administrator` WHERE username='$username' and password='$password'";
   
  $result = mysqli_query($dbc, $query) or die(mysqli_error($dbc));
  $count = mysqli_num_rows($result);
// If the posted values are equal to the database values, then session will be created for the user.
  if ($count == 1){
    $_SESSION['username'] = $username;
  }
  else{
// If the login credentials doesn't match, an error message displays.
    echo "Invalid Login Credentials. Please re-enter your username and password.";
  }
}
// If the user is logged in, Greetting message displays.
if (isset($_SESSION['username'])){
  $username = $_SESSION['username'];
  echo "Welcome " . $username . "
  ";
  echo "You are logged in
  ";
 
}
?>

</body>
</html>
