<?php
  // Define database connection constants
  define('DB_HOST', 'localhost');
  define('DB_USER', 'webuser');
  define('DB_PASSWORD', '');
  define('DB_NAME', 'foodpantdb');
  $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD); 
  $dbcon = mysqli_select_db($conn, DB_NAME);
  if ( !$conn ){
  	die("connection failed: " . mysqli_error());
  }
  if( !$dbcon ){
  	die("Database Connection failed : " . mysqli_error());
  }  
?>
