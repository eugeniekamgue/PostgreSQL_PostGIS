<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Foodpantry Registration Page</title>
</head>
<body>
  <h2>Foodpantry Registration Page</h2>

<?php
  require('header.php');
  $first_name = $_POST['firstname'];
  $last_name = $_POST['lastname'];
  $email = $_POST['email'];
  $username= $_POST['username'];
  $password= $_POST['password'];

  $dbc = mysqli_connect('localhost', 'webuser', '', 'foodpantdb')
    or die('Error connecting to MySQL server.');

  $query = "INSERT INTO administrator (name, email, username, password, approved) 
  VALUES ('$first_name', '$email', '$username', '$password', 1)";

  $result = mysqli_query($dbc, $query)
    or die('Error querying database.');

    mysqli_close($dbc);

  echo 'Hello: ' . $first_name . '<br />';
  echo 'Thanks for submitting your registration<br />';
  echo 'Your username is ' . $username . '<br />'; 
  echo 'Your email address is ' . $email . '<br />';
  echo 'Please, check your email to confirm your registration<br />';
?>

</body>
</html>
