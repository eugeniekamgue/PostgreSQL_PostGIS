<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Update Food Bank Inventory</title>
</head>
<body>
  <h2>Update Food Bank Inventory</h2>

<?php
  require('header.php');
  $foodbankid = $_POST['idFood_Bank'];
  $fooditemid = $_POST['idFood_Item'];
  $stock = $_POST['Stock'];
  $unit = $_POST['unit'];

  $dbc = mysqli_connect('localhost', 'webuser', '', 'foodpantdb')
    or die('Error connecting to MySQL server.');

  $query = "INSERT INTO fbinventory (idFood_Bank, idFood_Item, Stock, unit) 
  VALUES ('$foodbankid', '$fooditemid', '$stock', '$unit')";

  $result = mysqli_query($dbc, $query)
    or die('Error querying database.');

    mysqli_close($dbc);

  echo 'You have sucessfully update the food bank inventory<br />';

?>

</body>
</html>
