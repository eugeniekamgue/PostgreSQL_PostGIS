<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Foodpantry Locations</title>
</head>
<body>
  <h2>Foodpantry Locations</h2>

<?php
  require('header.php');
  include_once('dbconnect.php');

  #if (isset($_POST['city']) and isset($_POST['ZIP'])){
  #$city= $_POST['city'];
  #$ZIP= $_POST['ZIP'];
if(isset($_POST['search'])){
  $city= $_POST['city'];
  $ZIP= $_POST['ZIP'];
  $query = mysqli_query($conn, "SELECT * FROM `foodpantry` WHERE city='$city' AND ZIP='$ZIP'");
   
  #$result = mysqli_query($dbc, $query) or die(mysqli_error($dbc));
  $count = mysqli_num_rows($query);
  if ($count == 0){
    echo "No result found!";
  }
  else{
    while($row = mysql_fetch_array($query)){
      extract($row);
      echo "Your search returned the following results<br />";
      $s = $row['name'];
      $output .= '<h2>'.$s.'</h2><br>';
    }
  }
}
?>            

</body>
</html>